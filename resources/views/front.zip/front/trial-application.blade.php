<html>
<head></head>
<body>
<h1>Trial Class Application</h1>
<p>{{ $content }}</p>
</body>
</html>